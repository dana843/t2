class CompanyModel{

  CompanyModel({this.name, this.imageUrl, this.jobs});

  String? id;
  String? name;
  String? jobs;
  String? imageUrl;  
  String? address;  


  static const String idKey = 'id';
  static const String nameKey = 'name';
  static const String jobsKey = 'jobs';
  static const String imageUrlKey = 'image_url';
  static const String addressKey = 'adress';


  Map<String, dynamic> toJson({bool local = false, bool isUpdate = false}){
    return {
    idKey : id,
    jobsKey : jobs,
    nameKey : name,
    imageUrlKey :imageUrl,
    addressKey :address,
    };
  }

  CompanyModel.fromJson(Map<String, dynamic> json, {bool local = false}){
    id = json[idKey];
    name = json[nameKey];
    jobs = json[jobsKey];
    imageUrl = json[imageUrlKey];
    address = json[addressKey];
  }
}
class PlaceModel{

  PlaceModel({this.name, this.imageUrl, this.activity, this.address, this.description, this.numberOfPeople, this.price, this.tourismCompanyId, this.categoryId, this.tripDaysNumber});

  String? id;
  String? name;
  String? description;
  String? address;
  String? categoryId;
  String? activity;
  String? tourismCompanyId;
  num? price;
  int? numberOfPeople;
  String? imageUrl; 
  int? addedAt; 
  int? tripDaysNumber; 


  static const String idKey = 'id';
  static const String nameKey = 'name';
  static const String descriptionKey = 'description';
  static const String categoryIdKey = 'category_id';
  static const String addressKey = 'address';
  static const String activityKey = 'activity';
  static const String tourismCompanyIdKey = 'tourism_company_id';
  static const String priceKey = 'price';
  static const String numberOfPeopleKey = 'number_of_people';
  static const String imageUrlKey = 'image_url';
  static const String addedAtKey = 'added_at';
  static const String tripDaysNumberKey = 'trip_days_number';


  Map<String, dynamic> toJson({bool local = false, bool isUpdate = false}){
    return {
    nameKey : name,
    descriptionKey : description,
    addressKey : address,
    categoryIdKey : categoryId,
    activityKey : activity,
    tourismCompanyIdKey : tourismCompanyId,
    priceKey : price,
    numberOfPeopleKey : numberOfPeople,
    tripDaysNumberKey :tripDaysNumber,
      if(local) ...{
        idKey : id,
        addedAtKey : addedAt
      }else ...{
      },
    if(!isUpdate)...{
    imageUrlKey :imageUrl,
    },
    };
  }

  PlaceModel.fromJson(Map<String, dynamic> json, {bool local = false}){
    if(local){
      id = json[idKey];
    }
    name = json[nameKey];
    description = json[descriptionKey];
    categoryId = json[categoryIdKey];
    address = json[addressKey];
    activity = json[activityKey];
    tourismCompanyId = json[tourismCompanyIdKey];
    price= json[priceKey];
    numberOfPeople = json[numberOfPeopleKey];
    imageUrl = json[imageUrlKey];
    addedAt = json[addedAtKey];
    tripDaysNumber = json[tripDaysNumberKey];
  }



}

class UserModel{

  UserModel({this.name, this.email, this.phoneNumber, this.imageUrl, this.token, this.accountType, this.latitude, this.longitude, this.preferredActivity});

  String? id;
  String? name;
  String? imageUrl; 
  String? email;
  String? phoneNumber;
  String? token;
  int? accountType;
  double? latitude;
  double? longitude;
  String? preferredActivity;

  static const String idKey = 'id';
  static const String nameKey = 'name';
  static const String emailKey = 'email';
  static const String imageUrlKey = 'image_url';
  static const String phoneNumberKey = 'phone_number';
  static const String accountTypeKey = 'account_type';
  static const String tokenKey = 'token';
  static const String latitudeKey = 'latitude';
  static const String longitudeKey = 'longitude';
  static const String preferredActivityKey = 'preferred_activity';

  Map<String, dynamic> toJson({bool local = false}){
    return {
      if(local)...{
          idKey : id,
      },
    nameKey : name,
    imageUrlKey :imageUrl,
    emailKey :email,
    phoneNumberKey : phoneNumber,
    tokenKey : token,
    accountTypeKey : accountType,
    latitudeKey : latitude,
    longitudeKey : longitude,
    preferredActivityKey : preferredActivity,
    };
  }

  UserModel.fromJson(Map<String, dynamic> json){
    id = json[idKey];
    name = json[nameKey];
    imageUrl = json[imageUrlKey];
    phoneNumber = json[phoneNumberKey];
    email = json[emailKey];
    token = json[tokenKey];
    accountType = json[accountTypeKey] ?? 0;
    latitude = json[latitudeKey];
    longitude = json[longitudeKey];
    preferredActivity = json[preferredActivityKey];
  }


}
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:my_crew/feature/core/theme/size/size_manager.dart';
import 'package:my_crew/feature/view/widgets/app_back_button.dart';
import 'package:my_crew/feature/view/widgets/app_text_form_filed.dart';
import 'package:my_crew/utils/localization/string_keys.dart';

class AddJobScreen extends StatelessWidget {
  const AddJobScreen({super.key, this.isUpdate = false});

  final bool isUpdate;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(leading: const AppBackButton(), title: Text(isUpdate ? StringKeys.editJob.tr : StringKeys.addNewJob.tr),),
      body: ListView(
        padding: EdgeInsets.symmetric(horizontal: SizeManager.w12, vertical: SizeManager.h20),
        children: [
          AppTextFormFiled(controller: TextEditingController(), label: StringKeys.jobTitle.tr),
          SizedBox(height: SizeManager.h16,),
          Row(
            children: [
          Expanded(flex: 3, child: AppTextFormFiled(controller: TextEditingController(), label: StringKeys.jobType.tr)),
          SizedBox(width: SizeManager.w16,),
          Expanded(flex: 2, child: AppTextFormFiled(controller: TextEditingController(), label: StringKeys.salary.tr)),
            ],
          ),
          SizedBox(height: SizeManager.h16,),
          AppTextFormFiled(controller: TextEditingController(), label: StringKeys.jobDescription.tr, maxLines: 4,),
          SizedBox(height: SizeManager.h24,),
          ElevatedButton(onPressed: (){}, child: Text(isUpdate ? StringKeys.save.tr : StringKeys.add.tr))
        ],
      ),
    );
  }
}